module.exports = (sequelize, DataTypes) => {
  const UserWallets = sequelize.define(
    "user_wallets",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      user_id: DataTypes.INTEGER,
      wallet_type: DataTypes.STRING,
      wallet_account: DataTypes.STRING,
    },
    {
      timestamps: false,
    },
  );

  return UserWallets;
};
